import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Student from "./components/Student";
import Home from "./components/Home";
// import Course from "./components/Course";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/student" element={<Student />}></Route>
        {/* <Route path="/course" element={<Course />}></Route> */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
