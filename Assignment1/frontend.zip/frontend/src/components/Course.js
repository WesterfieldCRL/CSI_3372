import React from "react";

export default function Course(props) {
  return (
    <div>
      <h3> Course</h3>
    </div>
  );
}
