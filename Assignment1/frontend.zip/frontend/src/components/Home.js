import React, { Component } from "react";

export default function Home(props) {
  return (
    <div>
      <div>
        {" "}
        <a href="/student">Student</a>
      </div>

      <div>
        {" "}
        <a href="/course">Course</a>
      </div>
    </div>
  );
}
