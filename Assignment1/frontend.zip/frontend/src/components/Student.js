import React, { useState } from "react";

export default function Student(props) {
  const [name, setName] = useState();

  function onSubmit(event) {
    event.preventDefault();
    window.alert("Welcome " + name);
  }

  function handleNameChange(event) {
    setName(event.target.value);
  }
  return (
    <div>
      <h3> Student</h3>
      <form onSubmit={onSubmit}>
        <label for="name" required>
          Name
        </label>
        <input type="text" name="name" onChange={handleNameChange} />

        <button variant="contained" type="submit">
          {" "}
          Save{" "}
        </button>
      </form>
    </div>
  );
}
